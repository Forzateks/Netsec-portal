-- Projects table
create table projects (
  id bigint generated always as identity primary key,
  name text not null unique,
  status text default 'active',
  created_at timestamptz default now()
);

-- Project Sessions table
create table project_sessions (
  id bigint generated always as identity primary key,
  project_id bigint references projects(id),
  project_name text not null,
  session_date date not null,
  activity_type text,
  session_info text,
  start_time text,
  end_time text,
  duration_hours numeric(6,2),
  onsite_remote text,
  stake_holders text,
  team_members text,
  remarks text,
  logged_by text,
  created_at timestamptz default now()
);

alter table projects enable row level security;
alter table project_sessions enable row level security;
create policy "Allow all" on projects for all using (true) with check (true);
create policy "Allow all" on project_sessions for all using (true) with check (true);

-- Pre-load all 35 projects
insert into projects (name) values
  ('ABK'),('QDSBG'),('DH-NONCORP'),('MASHREQ-DCDR'),('MASHREQ-IBG'),
  ('ADAA'),('NBO-MSOT'),('ASIC'),('ARO-KSA'),('ENBD-OCI-KSA'),
  ('ENBD-MIGRATION'),('ATMC-ASIC'),('QIDDIYA'),('ENBD-MEYDAN'),
  ('DUBAI-PETROLEUM'),('DUBAI-HOLDING'),('FAB-MISR'),('LANDMARK'),
  ('RTA'),('ASTER-OMAN'),('ASTER-DUBAI'),('FAB'),('MAGNATI-FISERV'),
  ('ARO-DRILLING'),('TAAGEER-FINANCE'),('DFM'),('NAIVAS'),
  ('NAIVAS-PHASE2'),('ARABIAN-SHIELD'),('DERAYA-FINANCE'),
  ('MOH'),('QASSIM-UNIVERSITY'),('OLD-DUBAI-HOLDING'),
  ('OLD-MASHREQ'),('MASHREQ-IBG-OLD');
